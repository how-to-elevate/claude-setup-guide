"""Check this computer is ready, and optionally build the Python environment.

Usage: python check_setup.py            # report only
       python check_setup.py --install  # also build the environment

The packages go in their own folder, ~/.sort-my-media, because Macs with Homebrew Python
refuse system-wide installs. It sits in the home folder because a deep path breaks the
install on Windows, where some package files already have very long names.
"""
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# faster-whisper 1.2.1 breaks on av 19: every video comes back as "no speech".
PACKAGES = ["faster-whisper==1.2.1", "av<19", "pillow", "pillow_heif"]
GPU_PACKAGES = ["nvidia-cublas-cu12", "nvidia-cudnn-cu12"]


def nvidia():
    if not shutil.which("nvidia-smi"):
        return ""
    try:
        return subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=20).stdout.strip()
    except subprocess.SubprocessError:
        return ""


def main():
    win = sys.platform == "win32"
    ok = True
    print(f"System: {platform.system()} {platform.machine()}")
    print(f"Python: {platform.python_version()}")
    if sys.version_info < (3, 10):
        ok = False
        print("  TOO OLD: needs 3.10 or newer. " + ("winget install Python.Python.3.12" if win else "brew install python@3.12"))
    for tool in ("ffmpeg", "ffprobe"):
        found = shutil.which(tool)
        print(f"{tool}: {found or 'MISSING'}")
        ok = ok and bool(found)
    if not shutil.which("ffmpeg"):
        print("  Install: " + ("winget install Gyan.FFmpeg (then fully close and reopen Claude Code)" if win else "brew install ffmpeg"))
    card = nvidia() if win else ""
    print(f"Graphics card for transcribing: {card or 'none usable, the processor will do it (about 10x slower)'}")
    print(f"Free space here: {shutil.disk_usage(Path.cwd()).free / 1e9:.0f} GB")

    if "--install" in sys.argv:
        venv = Path.home() / ".sort-my-media"
        if not venv.exists():
            subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
        py = venv / ("Scripts/python.exe" if win else "bin/python")
        subprocess.run([str(py), "-m", "pip", "install", "--upgrade", "pip", "-q"], check=True)
        subprocess.run([str(py), "-m", "pip", "install", "-q", *PACKAGES, *(GPU_PACKAGES if card else [])], check=True)
        print(f"Environment ready. Run the other scripts with: {py}")
    print("READY" if ok else "NOT READY: fix the items above")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
