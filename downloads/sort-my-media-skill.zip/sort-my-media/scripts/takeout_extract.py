"""Unpack Google Takeout parts as they finish downloading, then remove each zip.

Usage: python -I takeout_extract.py <year> <takeout stamp> <parts> [downloads folder]
    e.g. python -I takeout_extract.py 2024 20261030T193957Z 19

Watches Downloads for takeout-<stamp>-...-NNN.zip (finished downloads only; Chrome keeps
.crdownload until done), tests each zip, extracts it into raw/<year>, logs it to
raw/extract-log.txt, then deletes the zip. A part that arrives as a single video instead of
a zip is moved into the album folder under its original name. Stops when every part is
accounted for. Safe to re-run: finished parts are read from the log.
"""
import re
import shutil
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import free_gb, raw  # noqa: E402

LOG = Path("raw/extract-log.txt")


def log(msg):
    line = f"{datetime.now():%Y-%m-%d %H:%M} {msg}"
    print(line, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def main(year, stamp, parts, downloads=None):
    out, parts = raw(year), int(parts)
    downloads = Path(downloads) if downloads else Path.home() / "Downloads"
    out.mkdir(parents=True, exist_ok=True)
    tag = f"takeout-{stamp}"
    done = set(re.findall(rf"{tag} part (\d+) extracted", LOG.read_text(encoding="utf-8"))) if LOG.exists() else set()
    done = {int(d) for d in done}
    bad = set()
    log(f"{tag}: watching {downloads}, {len(done)}/{parts} already done")
    while len(done | bad) < parts:
        for f in sorted(downloads.glob(f"{tag}-*")):
            m = re.search(r"-(\d{3})(?:\.\w+)?$", f.name)
            if not m or f.suffix == ".crdownload" or " (" in f.name or int(m[1]) in done | bad:
                continue
            n = int(m[1])
            if time.time() - f.stat().st_mtime < 30:
                continue
            if f.suffix.lower() == ".zip":
                try:
                    with zipfile.ZipFile(f) as z:
                        broken = z.testzip()
                        if broken:
                            raise zipfile.BadZipFile(broken)
                        z.extractall(out)
                except zipfile.BadZipFile as e:
                    log(f"{tag} part {n}: BAD zip ({e}), left in Downloads")
                    bad.add(n)
                    continue
            else:
                album = next((d for d in out.glob("Takeout/*/*") if d.is_dir()), out)
                name = re.sub(r"-\d{3}(\.\w+)$", r"\1", f.name.replace(f"{tag}-1-", ""))
                shutil.move(str(f), album / name)
                log(f"{tag} part {n}: not a zip, moved as {name}")
            if f.exists():
                f.unlink()
            done.add(n)
            log(f"{tag} part {n} extracted ({free_gb(out):.0f} GB free)")
        if len(done | bad) < parts:
            time.sleep(30)
    if bad:
        log(f"=== {tag}: {len(done)} parts done, BAD: {sorted(bad)}")
        return 1
    log(f"=== {tag}: ALL {parts} PARTS DONE")


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:5]))
