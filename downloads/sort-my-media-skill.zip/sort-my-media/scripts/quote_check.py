"""Check every quoted line in the review notes really belongs to that clip.

Usage: python -I quote_check.py <year>

Reviewers work through clips in bulk, and a note can slip onto the clip next door. If that
clip then gets labelled SKIP, a keeper is lost. Every "double quoted" span in the notes,
VOC tags and rescue lines is looked for in the clip's own transcript. A miss found in a
neighbouring clip (2 either side) is reported as SLIPPED. Fragments under three words are
ignored. publish.py won't copy anything until this passes.
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import batches, digest_entries, read_csv, video_notes  # noqa: E402

QUOTE = re.compile(r'["“]([^"“”]+)["”]')


def norm(s):
    return " ".join(re.sub(r"[^\w\s]", " ", s.lower()).split())


def fragments(text):
    for q in QUOTE.findall(text):
        for part in re.split(r"\.\.\.|…", q):
            part = norm(part)
            if len(part.split()) >= 3:
                yield part


def main(year):
    entries = digest_entries(year)
    order = [name for _, name, _ in entries]
    text = {name: norm(t) for _, name, t in entries}
    pos = {name: i for i, name in enumerate(order)}
    checks = [(r["file"], r["notes"]) for r in read_csv(video_notes(year))]
    for pat, col in (("voc-tags-*.txt", 2), ("voc-rescue-*.txt", 3)):
        for b in sorted(batches(year).glob(pat)):
            for line in b.read_text(encoding="utf-8").splitlines():
                parts = line.split("|")
                if len(parts) > col:
                    checks.append((parts[0].split("/", 1)[-1], parts[col]))

    misses = 0
    for name, note in checks:
        if name not in pos:
            print(f"UNKNOWN FILE {name}")
            misses += 1
            continue
        for frag in fragments(note):
            if frag in text[name]:
                continue
            i = pos[name]
            near = [n for n in order[max(0, i - 2):i + 3] if n != name and frag in text[n]]
            print(f"SLIPPED {name}: belongs to {near[0]}: {frag}" if near else f"NOT FOUND {name}: {frag}")
            misses += 1
    passed = batches(year) / "quote-check-passed.txt"
    if misses:
        passed.unlink(missing_ok=True)
        print(f"{misses} to fix. Check each against the transcript and the frame strip, "
              "correct the batch file, run merge_notes.py, then run this again.")
        return 1
    passed.write_text("ok\n", encoding="utf-8")
    print(f"All quotes check out across {len(checks)} notes.")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
