"""Batch-transcribe every video in raw/<year>, locally. Nothing is uploaded.

Usage: python -I transcribe_videos.py <year> [--model M] [--shard i/n]

Loads faster-whisper once and works through every video that doesn't have a
transcript yet, so it resumes after a restart and picks up newly extracted
parts on a re-run. Files touched in the last two minutes are left for next
time, in case they're still being extracted.

For each video it writes transcripts/<year>/<video name>.md (a stub saying "no
speech" when there's none) and a 3-frame strip frames/<year>/<video name>.jpg.
"""
import argparse
import glob
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import VIDEO, config, frames as frames_dir, raw, transcripts  # noqa: E402


def stamp(sec):
    m, s = divmod(int(sec), 60)
    return f"{m:02d}:{s:02d}"


def probe(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=60).stdout.strip()
        return float(out)
    except (ValueError, subprocess.SubprocessError):
        return 0.0


def frames(src, dest, dur):
    if dest.exists() or dur <= 0:
        return
    rate = 3 / max(dur, 1)
    subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", str(src), "-vf",
         f"fps={rate:.5f},scale=360:-2,tile=3x1", "-frames:v", "1", str(dest)],
        capture_output=True, timeout=300)


def load_model(name):
    # Graphics card only when its libraries are installed: without them the model
    # loads fine and then crashes on the first video. Otherwise the processor.
    libs = glob.glob(str(Path(sys.prefix) / "Lib/site-packages/nvidia/*/bin")) if sys.platform == "win32" else []
    for d in libs:
        os.add_dll_directory(d)
        os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
    from faster_whisper import WhisperModel
    if libs:
        try:
            model = WhisperModel(name, device="cuda", compute_type="int8_float16")
            print(f"model loaded on the graphics card: {name}", flush=True)
            return model
        except Exception as e:
            print(f"graphics card failed ({e!r}), using the processor", flush=True)
    print(f"model loaded on the processor: {name}", flush=True)
    return WhisperModel(name, device="cpu", compute_type="int8")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("year")
    p.add_argument("--model")
    p.add_argument("--shard", default="0/1",
                   help="i/n: take every n-th video starting at i, so n copies can run side by side")
    a = p.parse_args()
    shard, nshards = map(int, a.shard.split("/"))
    name = a.model or config().get("model", "distil-large-v3")

    root, out, fdir = raw(a.year), transcripts(a.year), frames_dir(a.year)
    out.mkdir(parents=True, exist_ok=True)
    fdir.mkdir(parents=True, exist_ok=True)

    now = time.time()
    todo = [f for f in sorted(root.rglob("*"))
            if f.is_file() and f.suffix.lower() in VIDEO
            and not (out / (f.name + ".md")).exists()
            and now - f.stat().st_mtime > 120][shard::nshards]
    print(f"{len(todo)} videos to do", flush=True)
    if not todo:
        print("DONE", flush=True)
        return

    model = load_model(name)
    failed = 0
    for i, f in enumerate(todo, 1):
        dur = probe(f)
        md = out / (f.name + ".md")
        try:
            frames(f, fdir / (f.name + ".jpg"), dur)
        except subprocess.SubprocessError:
            pass
        lines = []
        try:
            segs, info = model.transcribe(str(f), beam_size=5, vad_filter=True)
            for s in segs:
                t = s.text.strip()
                if t:
                    lines.append(f"**[{stamp(s.start)}]** {t}\n")
        except IndexError:  # no audio track: a silent clip, which is fine
            lines = []
        except Exception as e:  # no transcript saved, so a re-run tries it again
            print(f"  error on {f.name}: {e}", flush=True)
            failed += 1
            if failed >= 3:
                print("STOPPED: 3 videos in a row failed, so something's wrong with the setup, not the videos.", flush=True)
                return 1
            continue
        failed = 0
        head =[f"# {f.name}", "",
                f"Source: `{f.relative_to(root)}` ({stamp(dur)})",
                f"Transcribed locally with faster-whisper (`{name}`). No speaker labels.",
                "", "---", ""]
        body = lines or ["_No speech detected._\n"]
        try:
            md.write_text("\n".join(head + body), encoding="utf-8")
        except OSError as e:  # one unsaveable file shouldn't stop the whole batch
            print(f"  could not save {md}: {e}", flush=True)
            continue
        words = sum(len(l.split()) for l in lines)
        print(f"[{i}/{len(todo)}] {f.name} {stamp(dur)} {words} words", flush=True)

    print("DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())
