"""Inventory every photo and video in raw/<year>.

Usage: python -I build_inventory.py <year>

Reads each item's Google sidecar JSON for the taken date and place, and asks
ffprobe for video length. Safe to re-run as more parts are extracted; it
rebuilds the CSV from whatever is on disk.
"""
import csv
import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import PHOTO, VIDEO, inventory, raw, sidecar  # noqa: E402


def duration(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=60).stdout.strip()
        return round(float(out))
    except (ValueError, subprocess.SubprocessError):
        return ""


def main(year):
    root, out_csv = raw(year), inventory(year)
    rows = []
    for f in sorted(root.rglob("*")):
        ext = f.suffix.lower()
        if not f.is_file() or ext not in PHOTO | VIDEO:
            continue
        meta = {}
        sc = sidecar(f)
        if sc:
            try:
                meta = json.loads(sc.read_text(encoding="utf-8"))
            except ValueError:
                pass
        ts = int(meta.get("photoTakenTime", {}).get("timestamp", 0) or 0)
        geo = meta.get("geoData", {})
        kind = "video" if ext in VIDEO else "photo"
        rows.append({
            "file": str(f.relative_to(root)),
            "type": kind,
            "taken": dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M") if ts else "",
            "duration_s": duration(f) if kind == "video" else "",
            "size_mb": round(f.stat().st_size / 1e6, 1),
            "lat": geo.get("latitude") or "",
            "lon": geo.get("longitude") or "",
            "description": meta.get("description", ""),
        })
    if not rows:
        print(f"No photos or videos found in {root}")
        return 1
    rows.sort(key=lambda r: r["taken"])
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    vids = [r for r in rows if r["type"] == "video"]
    mins = sum(r["duration_s"] or 0 for r in vids) / 60
    print(f"{len(rows) - len(vids)} photos, {len(vids)} videos ({mins:.0f} min of video) -> {out_csv}")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
