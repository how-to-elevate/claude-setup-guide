"""Build a review pack for the transcribed videos: one numbered digest plus
numbered sheets of frame strips, so a reviewer can work through them in bulk.

Usage: python -I video_review_pack.py <year>

Run it once, after transcribing has finished: the review batches use its numbers.
Videos are numbered in date order (sidecar date, else the date in the filename).
"""
import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).parent))
from common import frames, inventory, name_date, pack, read_csv, transcripts  # noqa: E402

PER_SHEET = 8
COLS = 2
CELL_W, CELL_H = 540, 330


def main(year):
    tdir, fdir, out = transcripts(year), frames(year), pack(year)
    out.mkdir(parents=True, exist_ok=True)
    rows, missing = [], 0
    for r in read_csv(inventory(year)):
        if r["type"] != "video":
            continue
        name = Path(r["file"]).name
        t, f = tdir / (name + ".md"), fdir / (name + ".jpg")
        if not t.exists():
            missing += 1
            continue
        body = t.read_text(encoding="utf-8").split("---", 1)[-1]
        text = " ".join(re.sub(r"\*\*\[\d\d:\d\d\]\*\* ", "", body).split())
        date = r["taken"] or name_date(name)
        rows.append((date or "9999", name, r, text, f))
    rows.sort(key=lambda x: x[:2])

    lines = []
    for i, (date, name, r, text, f) in enumerate(rows, 1):
        gps = f" gps {float(r['lat']):.3f},{float(r['lon']):.3f}" if r["lat"] else ""
        src = "" if r["taken"] else " (date from filename)" if date != "9999" else " (no date)"
        lines.append(f"#{i} | {name} | {date if date != '9999' else '?'}{src} | "
                     f"{r['duration_s']}s{gps}\n{text or '[no speech]'}\n")
    (out / "digest.txt").write_text("\n".join(lines), encoding="utf-8")

    font = ImageFont.load_default(size=28)
    for s in range(0, len(rows), PER_SHEET):
        chunk = rows[s:s + PER_SHEET]
        nrows = (len(chunk) + COLS - 1) // COLS
        sheet = Image.new("RGB", (CELL_W * COLS, CELL_H * nrows), "white")
        d = ImageDraw.Draw(sheet)
        for k, (_, name, _, _, f) in enumerate(chunk):
            x, y = (k % COLS) * CELL_W, (k // COLS) * CELL_H
            if f.exists():
                im = Image.open(f)
                im.thumbnail((CELL_W - 10, CELL_H - 40))
                sheet.paste(im, (x + 5, y + 36))
            d.text((x + 5, y + 2), f"#{s + k + 1}", fill="red", font=font)
        sheet.save(out / f"sheet-{s // PER_SHEET + 1:03d}.jpg", quality=80)
    print(f"{len(rows)} videos -> {out}")
    if missing:
        print(f"WARNING: {missing} videos have no transcript yet. Finish transcribing and run this again before reviewing.")


if __name__ == "__main__":
    main(sys.argv[1])
