"""Copy a year's keepers to the media library and write their index.

Usage: python -I publish.py <year>         # copy (resumable), verify, write index
       python -I publish.py <year> index   # only rewrite the index and the for-you list

Reads config.json for the destination. Labels copied: AD, TALK, B-ROLL, POSTED, and "keeper"
photos. Files keep their original names and go to <dest>/videos/<year>/<label folder>/ and
<dest>/photos/<year>/. Everything else stays in Google Photos only. Originals in raw/ are
only read. Google Drive for desktop holds copies on the main disk until they upload, so with
a Drive destination copying waits whenever free space drops under min_free_gb.

Flags come from the "## Flags" section of privacy.md: "word, word | Flag text" per line.
An optional review/<year>/start-here.md is placed at the top of the index.
Log: catalogue/publish-<year>.log
"""
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).parent))
from common import (KEEP, batches, config, free_gb, inventory, name_date, photo_calls,  # noqa: E402
                    raw, read_csv, transcripts, video_notes)

LIB = Path("library")
SECTIONS = [("AD", "Ad takes"), ("TALK", "Talking to camera"), ("POSTED", "Already posted"), ("B-ROLL", "B-roll")]


def log(year, msg):
    line = f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    print(line, flush=True)
    with open(Path("catalogue") / f"publish-{year}.log", "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_flags():
    flags = []
    text = Path("privacy.md").read_text(encoding="utf-8") if Path("privacy.md").exists() else ""
    section = text.split("## Flags", 1)[-1] if "## Flags" in text else ""
    for line in section.split("\n## ")[0].splitlines():
        if "|" in line:
            words, flag = line.lstrip("- ").rsplit("|", 1)
            pat = "|".join(re.escape(w.strip()) for w in words.split(",") if w.strip())
            if pat:
                flags.append((rf"\b(?:{pat})", flag.strip()))
    return flags


def cell(s):
    return " ".join(str(s).replace("|", "/").split())


def opening(t):
    if not t.exists():
        return ""
    body = t.read_text(encoding="utf-8").split("---", 1)[-1]
    words = re.sub(r"\*\*\[\d\d:\d\d\]\*\* ", "", body).split()
    if not words or words[0] == "_No":
        return ""
    return " ".join(words[:18]) + ("..." if len(words) > 18 else "")


def mmss(s):
    try:
        s = round(float(s))
    except ValueError:
        return "?"
    return f"{s // 60}:{s % 60:02d}"


def copy_all(year, pairs, cfg):
    dest, limit = Path(cfg["dest"]), cfg.get("min_free_gb", 40)
    log(year, f"copy start: {len(pairs)} files, {sum(s.stat().st_size for s, _ in pairs) / 1e9:.1f} GB")
    done = skipped = 0
    for i, (src, dst) in enumerate(pairs, 1):
        if dst.exists() and dst.stat().st_size == src.stat().st_size:
            skipped += 1
            continue
        while min(free_gb(Path.home()), free_gb(dest)) < limit:
            if cfg.get("dest_type") != "drive":
                log(year, f"STOPPED: under {limit} GB free. Clear some space and run this again; it carries on.")
                sys.exit(1)
            log(year, f"under {limit} GB free, waiting for Drive to upload")
            time.sleep(300)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        done += 1
        if done % 50 == 0:
            log(year, f"{i}/{len(pairs)} copied")
    log(year, f"=== COPY DONE: {done} copied, {skipped} already there")


def verify(year, pairs):
    bad = [d for s, d in pairs if not d.exists() or d.stat().st_size != s.stat().st_size]
    for d in bad:
        log(year, f"MISMATCH {d}")
    log(year, f"=== VERIFY: {len(bad)} missing or wrong size")
    return bad


def write_root_index():
    years = sorted((p.stem.split("-")[1] for p in LIB.glob("INDEX-*.md")), reverse=True)
    out = ["# Media library", "",
           "Search these before asking for photos or clips. Read the flags before using anything.", ""]
    out += [f"- [{y}](INDEX-{y}.md)" for y in years]
    if (LIB / "VOC-CLIPS.md").exists():
        out += ["", "[Clips that say what your audience says](VOC-CLIPS.md)"]
    (LIB / "INDEX.md").write_text("\n".join(out) + "\n", encoding="utf-8")


def write_index(year, vrows, prows, cfg):
    flags = load_flags()

    def flags_for(note):
        return [f for pat, f in flags if re.search(pat, note, re.I)]

    dest = Path(cfg["dest"])
    inv = {Path(r["file"]).name: r for r in read_csv(inventory(year))}
    tout = LIB / "transcripts" / str(year)
    tout.mkdir(parents=True, exist_ok=True)
    groups = {k: [] for k, _ in SECTIONS}
    for r in vrows:
        name, k = r["file"], r["call"]
        if k not in KEEP:
            continue
        t = transcripts(year) / (name + ".md")
        tlink = ""
        if t.exists():
            shutil.copy2(t, tout / t.name)
            tlink = f"[read](transcripts/{year}/{quote(t.name)})"
        fl = flags_for(r["notes"])
        if not (dest / "videos" / str(year) / KEEP[k] / name).exists():
            fl.append("Not in the library yet")
        info = inv.get(name, {})
        date = (info.get("taken") or name_date(name) or "?")[:10]
        groups[k].append((date, f"| `{KEEP[k]}/{cell(name)}` | {date} | {mmss(info.get('duration_s', ''))} | "
                                f"{cell(r['notes'])} | {cell(opening(t))} | {', '.join(fl)} | {tlink} |"))
    nv = sum(len(v) for v in groups.values())
    keep = [r for r in prows if r["call"] == "keeper"]
    out = [f"# Media library: {year}", "",
           f"Keeper videos and photos from Google Photos {year}. Videos are in `{dest / 'videos' / str(year)}`, one "
           f"folder per type (the first part of each file name below). Photos are in `{dest / 'photos' / str(year)}`. "
           "Everything else stayed in Google Photos only. Descriptions come from three frames (videos) or a thumbnail "
           "(photos), plus the transcript. Read the flags before using anything.", ""]
    start = batches(year) / "start-here.md"
    if start.exists():
        out += ["## Start here", "", start.read_text(encoding="utf-8").strip(), ""]
    out += [f"## Videos ({nv})", ""]
    for k, title in SECTIONS:
        out += [f"### {title} ({len(groups[k])})", "",
                "| File | Date | Length | What it is | Opening line | Flags | Transcript |",
                "|---|---|---|---|---|---|---|", *[line for _, line in sorted(groups[k])], ""]
    out += [f"## Photos ({len(keep)})", "", "| File | Code | What it is | Flags |", "|---|---|---|---|"]
    for r in keep:
        fl = flags_for(r["notes"])
        if not (dest / "photos" / str(year) / r["file"]).exists():
            fl.append("Not in the library yet")
        out.append(f"| `{cell(r['file'])}` | {r['code']} | {cell(r['notes'])} | {', '.join(fl)} |")
    (LIB / f"INDEX-{year}.md").write_text("\n".join(out) + "\n", encoding="utf-8")
    write_root_index()
    log(year, f"index written: {nv} videos, {len(keep)} photos")

    # Short list of what needs the owner, nothing else. Stays on this computer.
    hold_v = [r for r in vrows if r["call"] == "HOLD"]
    hold_p = [r for r in prows if r["call"] == "hold"]
    sens = [r for r in prows if r["call"] == "sensitive"]
    rv = [f"# {year}: for you to look at when it suits", "",
          "Nothing here blocks the rest. None of it was copied to the library.", "",
          f"## Held back for you to decide ({len(hold_v)} videos, {len(hold_p)} photos)", "",
          "Personal material that stays in Google Photos unless you say otherwise.", ""]
    rv += [f"- `{r['file']}`: {r['notes']}" for r in hold_v] + [f"- `{r['file']}` ({r['code']}): {r['notes']}" for r in hold_p]
    rv += ["", f"## Photos holding ID or personal data ({len(sens)})", "",
           "Passports, licences, bank cards, other people's private messages. Worth deleting from "
           "Google Photos yourself. This is only a list.", ""]
    rv += [f"- `{r['file']}` ({r['code']}): {r['notes']}" for r in sens]
    (Path("catalogue") / f"{year}-for-you.md").write_text("\n".join(rv) + "\n", encoding="utf-8")


def main(year, mode=None):
    cfg = config()
    vrows = read_csv(video_notes(year))
    prows = read_csv(photo_calls(year))
    if mode != "index":
        passed = batches(year) / "quote-check-passed.txt"
        if not passed.exists() or passed.stat().st_mtime < video_notes(year).stat().st_mtime:
            print("Run quote_check.py first: it has to pass on the latest notes before anything is copied.")
            return 1
        paths = {f.name: f for f in raw(year).rglob("*") if f.is_file()}
        dest = Path(cfg["dest"])
        pairs = [(r["file"], dest / "videos" / str(year) / KEEP[r["call"]] / r["file"]) for r in vrows if r["call"] in KEEP]
        pairs += [(r["file"], dest / "photos" / str(year) / r["file"]) for r in prows if r["call"] == "keeper"]
        for name, _ in pairs:
            if name not in paths:
                log(year, f"NOT FOUND in raw: {name}")
        pairs = [(paths[n], d) for n, d in pairs if n in paths]
        copy_all(year, pairs, cfg)
        if verify(year, pairs):
            return 1
    write_index(year, vrows, prows, cfg)
    log(year, f"=== PUBLISH {year} DONE")


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:3]))
