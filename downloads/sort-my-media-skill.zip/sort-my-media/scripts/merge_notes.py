"""Turn the review batches into the year's notes files. Safe to re-run; it rebuilds both.

Usage: python -I merge_notes.py <year>

Video batches review/<year>/bNNN.txt: "<number>|<LABEL>|<note>", numbers from the digest.
Photo batches review/<year>/pNNN.txt: "<code>|<label>|<note>", codes from sheets.csv. A photo
with no line counts as not kept. Numbers become file names here. Reports any video with no
line and any label that isn't on the list, so nothing slips through unreviewed.
"""
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import (PHOTO_LABELS, VIDEO_LABELS, batches, digest_entries, pack, photo_calls,  # noqa: E402
                    read_csv, sheets, video_notes)


def lines(pattern, year):
    for b in sorted(batches(year).glob(pattern)):
        for n, line in enumerate(b.read_text(encoding="utf-8").splitlines(), 1):
            if line.strip():
                yield b.name, n, line


def main(year):
    problems = []
    names = {n: name for n, name, _ in digest_entries(year)} if (pack(year) / "digest.txt").exists() else {}
    notes = {}
    for src, n, line in lines("b[0-9]*.txt", year):
        parts = line.split("|", 2)
        if len(parts) < 3 or not parts[0].strip().isdigit() or int(parts[0]) not in names:
            problems.append(f"{src} line {n}: can't read: {line[:60]}")
            continue
        call = parts[1].strip().upper()
        if call not in VIDEO_LABELS:
            problems.append(f"{src} line {n}: unknown label {call}")
            continue
        notes[int(parts[0])] = [names[int(parts[0])], call, parts[2].strip()]
    with open(video_notes(year), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file", "call", "notes"])
        w.writerows(notes[k] for k in sorted(notes))
    gaps = sorted(set(names) - set(notes))
    if gaps:
        problems.append(f"{len(gaps)} videos have no review line: {gaps[:20]}")
    print(f"{len(notes)} video notes -> {video_notes(year)}")

    manifest = sheets(year) / "sheets.csv"
    code2file = {r["code"]: Path(r["file"]).name for r in read_csv(manifest)} if manifest.exists() else {}
    calls = {}
    for src, n, line in lines("p[0-9]*.txt", year):
        parts = line.split("|", 2)
        if len(parts) < 3 or parts[0].strip() not in code2file:
            problems.append(f"{src} line {n}: can't read: {line[:60]}")
            continue
        call = parts[1].strip().lower()
        if call not in PHOTO_LABELS:
            problems.append(f"{src} line {n}: unknown label {call}")
            continue
        code = parts[0].strip()
        calls[code] = {"code": code, "file": code2file[code], "call": call, "notes": parts[2].strip()}
    with open(photo_calls(year), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["code", "file", "call", "notes"])
        w.writeheader()
        w.writerows(calls[k] for k in sorted(calls))
    print(f"{len(calls)} photo calls ({sum(r['call'] == 'keeper' for r in calls.values())} keepers) "
          f"out of {len(code2file)} photos -> {photo_calls(year)}")

    for p in problems:
        print("PROBLEM:", p)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
