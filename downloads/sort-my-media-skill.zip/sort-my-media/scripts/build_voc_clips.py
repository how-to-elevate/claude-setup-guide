"""Build library/VOC-CLIPS.md: every clip that says what the audience says, by theme.

Usage: python -I build_voc_clips.py

Reads themes.md ("T1 | Theme name | phrases"), every review/<year>/voc-tags-*.txt
("<year>/<file>|T1 T4|"verbatim line"|use note") and voc-rescue-*.txt
("<year>/<file>|<LABEL>|T9|"verbatim line"|why"). Optional best-clips.txt lists the top
picks, one "<year>/<file>" per line. Themes with no clip are listed as gaps: go and film those.
"""
import collections
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import KEEP, config, read_csv  # noqa: E402


def main():
    dest = Path(config()["dest"]) / "videos"
    names = {}
    for line in Path("themes.md").read_text(encoding="utf-8").splitlines():
        m = re.match(r"\W*(T\d+)\s*\|\s*([^|]+)", line)
        if m:
            names[m[1]] = m[2].strip()

    calls = {}
    for f in Path("catalogue").glob("*-video-notes.csv"):
        y = f.name.split("-")[0]
        for r in read_csv(f):
            calls[f"{y}/{r['file']}"] = r["call"]

    rows = []
    for b in sorted(Path("review").glob("*/voc-tags-*.txt")):
        for line in b.read_text(encoding="utf-8").splitlines():
            if line.count("|") < 3:
                continue
            key, themes, quote, use = line.split("|", 3)
            y, f = key.split("/", 1)
            path = dest / y / KEEP.get(calls.get(key, ""), "?") / f
            rows.append((key, themes.split(), quote, use, path, path.exists()))
    by = collections.defaultdict(list)
    for r in rows:
        for t in r[1]:
            by[t].append(r)

    out = ["# Clips that say what your audience says", "",
           f"Every talking, ad and posted clip was read against the themes in themes.md. These are the {len(rows)} "
           "that say something your audience says. A clip can sit under more than one theme.", ""]
    best = Path("best-clips.txt")
    if best.exists():
        idx = {r[0]: r for r in rows}
        picks = [idx[k.strip()] for k in best.read_text(encoding="utf-8").splitlines() if k.strip() in idx]
        if picks:
            out += ["**Best to start with:**", ""] + [f"- `{r[4]}`: {r[2]}" for r in picks] + [""]
    out += ["**Before using any clip:** check its flags in the year's index.", ""]
    for t in sorted(by, key=lambda x: int(x[1:]) if x[1:].isdigit() else 999):
        out += [f"## {t}. {names.get(t, '')}", ""]
        for key, themes, quote, use, path, ok in by[t]:
            out += [f"- `{path}`", f"  - {quote}", f"  - {use}"]
        out.append("")
    gaps = [t for t in names if t not in by]
    if gaps:
        out += ["## Gaps: no clip yet, worth filming", ""] + [f"- {t}. {names[t]}" for t in gaps] + [""]

    resc = []
    for b in sorted(Path("review").glob("*/voc-rescue-*.txt")):
        resc += [l.split("|", 4) for l in b.read_text(encoding="utf-8").splitlines() if l.count("|") >= 4]
    if resc:
        out += ["## Not kept, but worth fetching back", "",
                "These weren't copied to the library. They're still in Google Photos: search the file name, then "
                "press Shift+D to download. Most need someone's OK first.", ""]
        for key, lab, th, line, why in resc:
            out += [f"- `{key}` (was {lab}, {th})", f"  - {line}", f"  - {why}"]
        out.append("")
    Path("library").mkdir(exist_ok=True)
    Path("library/VOC-CLIPS.md").write_text("\n".join(out), encoding="utf-8")
    print(f"{len(rows)} clips, {sum(not r[5] for r in rows)} paths not found, gaps: {gaps}")
    for r in rows:
        if not r[5]:
            print("MISSING", r[0], calls.get(r[0]))


if __name__ == "__main__":
    main()
