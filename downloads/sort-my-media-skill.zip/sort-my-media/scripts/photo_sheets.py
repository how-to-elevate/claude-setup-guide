"""Build contact sheets for the photos in raw/<year>.

Usage: python -I photo_sheets.py <year>

Each sheet is a 6x4 grid of thumbnails, each labelled with a short code
(sheet-cell, e.g. 003-17), the filename and the date taken. The mapping of
code -> file is kept in sheets/<year>/sheets.csv. Photos already on a sheet
are skipped, so re-run it after new Takeout parts are extracted and only the
new photos get sheets. Originals are only read, never changed.
"""
import csv
import datetime as dt
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps
import pillow_heif

sys.path.insert(0, str(Path(__file__).parent))
from common import PHOTO, name_date, raw, read_csv, sheets, sidecar  # noqa: E402

pillow_heif.register_heif_opener()

COLS, ROWS = 6, 4
CELL_W, THUMB_H, LABEL_H = 300, 300, 40
PAD = 6


def taken(media):
    """Best date for a photo: Google sidecar, then EXIF, then the filename."""
    sc = sidecar(media)
    if sc:
        try:
            ts = int(json.loads(sc.read_text(encoding="utf-8"))
                     .get("photoTakenTime", {}).get("timestamp", 0) or 0)
            if ts:
                return dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
        except ValueError:
            pass
    try:
        with Image.open(media) as im:
            exif = im.getexif()
            stamp = exif.get_ifd(0x8769).get(36867) or exif.get(306)
            if stamp:
                return dt.datetime.strptime(stamp[:16], "%Y:%m:%d %H:%M").strftime("%Y-%m-%d %H:%M")
    except Exception:
        pass
    return name_date(media.name)


def font(size):
    for name in ("arial.ttf", "Arial.ttf", "segoeui.ttf", "Helvetica.ttc"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def thumb(path):
    try:
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((CELL_W - 2 * PAD, THUMB_H - 2 * PAD))
            return im, None
    except Exception as e:
        return None, str(e)[:40]


def main(year):
    root, out_dir = raw(year), sheets(year)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = out_dir / "sheets.csv"
    done, rows = set(), []
    if manifest.exists():
        rows = read_csv(manifest)
        done = {r["file"] for r in rows}
    next_sheet = max((int(r["code"][:3]) for r in rows), default=0) + 1

    todo = [f for f in sorted(root.rglob("*"))
            if f.is_file() and f.suffix.lower() in PHOTO
            and str(f.relative_to(root)) not in done]
    if not todo:
        print("Nothing new to put on a sheet.")
        return
    dated = sorted(((taken(f), f) for f in todo), key=lambda t: (t[0] or "9999", t[1].name))

    f_code, f_small = font(17), font(13)
    per = COLS * ROWS
    new_rows = []
    for start in range(0, len(dated), per):
        batch = dated[start:start + per]
        sheet = Image.new("RGB", (COLS * CELL_W, ROWS * (THUMB_H + LABEL_H)), "white")
        draw = ImageDraw.Draw(sheet)
        name = f"photos-{next_sheet:03d}.jpg"
        for i, (when, f) in enumerate(batch):
            x, y = (i % COLS) * CELL_W, (i // COLS) * (THUMB_H + LABEL_H)
            code = f"{next_sheet:03d}-{i + 1:02d}"
            im, err = thumb(f)
            if im:
                sheet.paste(im, (x + (CELL_W - im.width) // 2, y + (THUMB_H - im.height) // 2))
            else:
                draw.text((x + PAD, y + THUMB_H // 2), f"can't open: {err}", fill="red", font=f_small)
            draw.text((x + PAD, y + THUMB_H), code, fill="black", font=f_code)
            draw.text((x + PAD + 70, y + THUMB_H + 3), (when or "no date"), fill="#444", font=f_small)
            draw.text((x + PAD, y + THUMB_H + 21), f.name[:38], fill="#666", font=f_small)
            new_rows.append({"code": code, "sheet": name, "file": str(f.relative_to(root)),
                             "taken": when, "error": err or ""})
        sheet.save(out_dir / name, quality=85)
        print(f"{name}: {len(batch)} photos")
        next_sheet += 1

    with open(manifest, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=["code", "sheet", "file", "taken", "error"])
        w.writeheader()
        w.writerows(rows + new_rows)
    print(f"{len(new_rows)} photos on {len(range(0, len(dated), per))} new sheets -> {out_dir}")


if __name__ == "__main__":
    main(sys.argv[1])
