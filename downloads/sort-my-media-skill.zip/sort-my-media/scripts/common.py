"""Shared paths and helpers. Every script runs from the media-archive folder."""
import csv
import glob
import json
import re
import shutil
from pathlib import Path

PHOTO = {".jpg", ".jpeg", ".png", ".heic", ".webp", ".gif"}
VIDEO = {".mp4", ".mov", ".m4v", ".3gp", ".avi", ".mkv"}

# Video labels that get copied, and the folder each goes in.
KEEP = {"AD": "ad-takes", "TALK": "talking-to-camera", "B-ROLL": "b-roll", "POSTED": "already-posted"}
VIDEO_LABELS = set(KEEP) | {"OTHERS", "PRIVATE", "INTERNAL", "HOLD", "SKIP"}
PHOTO_LABELS = {"keeper", "others", "private", "sensitive", "internal", "hold", "junk"}


def raw(y): return Path("raw") / str(y)
def inventory(y): return Path("catalogue") / f"{y}-inventory.csv"
def video_notes(y): return Path("catalogue") / f"{y}-video-notes.csv"
def photo_calls(y): return Path("catalogue") / f"{y}-photo-calls.csv"
def transcripts(y): return Path("transcripts") / str(y)
def frames(y): return Path("frames") / str(y)
def pack(y): return Path("review") / str(y) / "pack"
def batches(y): return Path("review") / str(y)
def sheets(y): return Path("sheets") / str(y)


def config():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def free_gb(path):
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free / 1e9


def sidecar(media):
    # Google truncates sidecar names, so match on the media name's prefix.
    exact = media.with_name(media.name + ".supplemental-metadata.json")
    if exact.exists():
        return exact
    for prefix in (media.name[:40], media.stem + "."):
        for j in media.parent.glob(glob.escape(prefix) + "*.json"):
            return j
    return None


def name_date(name):
    m = re.search(r"(20\d{2})(\d{2})(\d{2})[_-]?(\d{2})?(\d{2})?", name)
    if not m:
        return ""
    return f"{m[1]}-{m[2]}-{m[3]}" + (f" {m[4]}:{m[5]}" if m[4] and m[5] else "")


def digest_entries(y):
    """[(number, file name, flattened transcript)] from the review pack digest."""
    text = (pack(y) / "digest.txt").read_text(encoding="utf-8")
    return [(int(m[1]), m[2], m[3]) for m in re.finditer(r"^#(\d+) \| (.+?) \| .*\n(.*)$", text, re.M)]
