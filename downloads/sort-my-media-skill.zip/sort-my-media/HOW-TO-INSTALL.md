# How to install the /sort-my-media skill

This works in **Claude Code** (the VS Code extension, the desktop app's Code tab, or the terminal), not the normal Claude chat app.

1. Unzip this file. You'll get a folder called `sort-my-media` with `SKILL.md` inside.
2. Put that `sort-my-media` folder in your Claude skills folder:
   - **Windows:** `C:\Users\<your name>\.claude\skills\`
   - **Mac:** `~/.claude/skills/` (in Finder, press Cmd+Shift+G and paste that path)
   - If there's no `skills` folder, create one. `.claude` is a hidden folder.
3. Close and reopen Claude Code.
4. Open your usual Claude folder, the one with your business files in it, and type `/sort-my-media`.

Or skip the folders: open Claude Code, attach the zip, and say "install this as a user-level skill called sort-my-media". It'll put it in the right place.

Have a read of `WHAT-TO-EXPECT.md` first. It's one page.

It builds a `media-archive` folder wherever you run it. Claude installs everything else it needs and tells you if it needs anything from you.

**On a Mac:** this was built and tested on Windows. It's written to work on Mac, but it hasn't been run on one yet, so if something trips up, tell your Claude what happened and let the person who sent you this know.
