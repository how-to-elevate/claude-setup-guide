# Photo review brief template

Fill in the [BRACKETS] and save as `review/<year>/BRIEF-photos.md`, then give each reviewer the path and their sheet range.

---

# [YEAR] photo review brief

Working folder: [FULL PATH TO media-archive]

[TWO LINES ON THE OWNER: what they do, who's in their life, what they look like if known. What their audience needs to see.]

## Inputs
- Contact sheets: `sheets/[YEAR]/photos-NNN.jpg`, 24 photos each. Every photo has a code under it, like 003-17.
- Labels: [PATH TO references/labels.md].
- Privacy rules: `privacy.md`. These override everything.
- Audience themes: `themes.md`. A keeper is a photo that could sit next to one of these themes, or shows the owner's real life and work.

## Output
Write `review/[YEAR]/pNNN.txt`, using the same number as the sheet, one line per photo worth noting:

`code|label|note`

- Only write lines for keeper, others, private, sensitive, internal and hold. Anything with no line counts as junk.
- One line per code. "Covers 003-04 to 003-09" only labels the first one, so a burst of the same shot gets one line for the best frame and the rest stay unlisted.
- Be picky. Duplicates, near-duplicates, receipts, memes and screenshots of nothing are junk.
- Every passport, licence, bank card, boarding pass, payment screen or other person's private message gets a `sensitive` line, even in the corner of a shot.
- Note style: one short plain line saying what's in it and what it could be used for. Mention anything on the Flags list in privacy.md by name.

Examples:
003-02|keeper|Owner at the desk by the window, laptop open, morning light. Good for "working from home" posts.
003-11|private|Partner and kids at the table.
003-17|sensitive|Passport photo page.
004-06|others|Client group on the steps, faces clear. Needs their OK.

## Rules
- Don't edit any other file. Don't copy or move media.
- When done, reply with: sheets covered, count per label, and the best 5 keepers.
