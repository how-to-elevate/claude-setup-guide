# Labels

Every clip and photo gets exactly one label. If two could apply, the more private one wins.

## Videos (capitals)

| Label | What it means | Copied to the library? |
|---|---|---|
| AD | The owner talking to camera in a way usable as an ad or funnel video | Yes |
| TALK | The owner talking to camera, less polished: selfie, vlog, teaching thought | Yes |
| B-ROLL | Usable visuals with no private people: the work, the place, the owner doing things | Yes |
| POSTED | An edited or captioned version that already went out | Yes |
| OTHERS | Identifiable people who haven't agreed: clients, friends, kids in a lesson, team, testimonials | No, needs their OK |
| PRIVATE | Family, partner in personal moments, children, friends socialising, clips forwarded by someone else | No |
| INTERNAL | Screen recordings, team training, Zoom calls, systems demos | No |
| HOLD | Heavy personal material: loss, grief, illness, a hard day that might be a story one day | No, listed for the owner |
| SKIP | Nothing usable: blurry, pocket, floor, seconds of nothing | No |

## Photos (lower case)

| Label | What it means | Copied? |
|---|---|---|
| keeper | Good enough to use, nothing private in it | Yes |
| others | Identifiable people who haven't agreed | No |
| private | Family, children, personal moments | No |
| sensitive | Passports, licences, bank cards, payment screens, boarding passes, client data, other people's messages, nudity | No, listed for the owner to delete |
| internal | Screenshots and work admin | No |
| hold | Same as HOLD above | No, listed for the owner |
| junk | Anything else | No |

## Rules that never bend

- Children are never keepers unless they're the owner's own and the owner has said so in privacy.md.
- Anything on the "never use" list in privacy.md is PRIVATE, however good the shot is.
- HOLD material is never raised, suggested or used unless the owner brings it up. Don't quote it in the index.
- Being unsure means not copying. It stays safe in Google Photos and can be fetched later.
