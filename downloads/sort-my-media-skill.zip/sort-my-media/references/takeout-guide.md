# Getting a year out of Google Photos

Google closed off direct access to Photos in March 2025, so Takeout is the only way. Give these steps one at a time. The person does the clicking themselves: Google counts every click against a download limit, so automated clicking can burn an export.

## Request the export
1. Use Chrome on a computer, signed in to the account that holds the photos. Safari unzips files by itself and breaks this.
2. Go to takeout.google.com.
3. Click **Deselect all**.
4. Scroll to **Google Photos** and tick it.
5. Click **All photo albums included**, then **Deselect all**, then tick only **Photos from YYYY**. Click OK.
6. Click **Next step**. Choose **Send download link via email**, **Export once**, file type **.zip**, size **10 GB**.
7. Click **Create export**, then wait for the email from Google. Its button opens the page with the download links.

Prep time varies. A 172 GB year took 13 minutes for one person, but Google says it can take hours or days.

## Before downloading
- In Chrome settings, under Downloads, turn off **Ask where to save each file**.
- Check the total size on the export page. Free space needed is roughly that size plus 60 GB, because each zip gets unpacked and deleted one at a time.
- Plug the computer in and stop it going to sleep.
- Note the number of parts and the stamp in the file name (takeout-**20261030T193957Z**-1-001.zip). The extract script needs both.

## Downloading
- **Click every part once, in one sitting.** Each part can only be downloaded 5 times. After that the whole export is dead and has to be requested again.
- Never click a part again to "retry" because nothing seems to happen. Wait 3 minutes. If Google asks for a password or passkey, do that, and the download starts by itself.
- Google asks to confirm it's you again every 40 to 60 minutes. Starting everything in one go while signed in avoids most of it.
- Chrome runs a few at a time and queues the rest.
- If a download stalls, press Ctrl+J (Cmd+Shift+J on Mac) and click **Resume**. Don't start it again from Google.
- Chrome shows sizes oddly during big downloads. Falling free disk space is the real sign it's working.
- A file named "...005 (1).zip" is a duplicate. Ignore it and delete it when the year is finished.
- One part may arrive as a single big video rather than a zip. That's normal and the script handles it.

## Deadlines
Links stop working 7 days after the email. Download within that window.
