# Video review brief template

Fill in the [BRACKETS] and save as `review/<year>/BRIEF.md`, then give each reviewer the path, their number range and their batch numbers.

---

# [YEAR] video review brief

Working folder: [FULL PATH TO media-archive]

[TWO LINES ON THE OWNER: what they do, where they live, who's in their life, what they look like if known. Their audience in one line.]

## Inputs
- Digest: `review/[YEAR]/pack/digest.txt`. Each video: `#N | file | date | duration gps`, then its transcript.
- Frame strips: `review/[YEAR]/pack/sheet-NNN.jpg`, 8 videos per sheet, video #N is on sheet ceil(N/8). Open every sheet in your range. The picture decides most labels.
- Labels: [PATH TO references/labels.md]. Use exactly those words.
- Privacy rules: `privacy.md`. These override everything.
- Audience themes: `themes.md`, T1 to T[N].

## Output 1: review lines
Write `review/[YEAR]/bNNN.txt` (your assigned numbers), about 25 lines per file, one line per video in your range with no gaps:

`N|LABEL|note`

Note style: short and plain. Start with what's on screen. Quote speech only word for word from the digest, in "double quotes", with ... for cuts. Never invent or tidy a quote. Words on screen go in 'single quotes'. Write "needs X's OK" for testimonials. Mention anything on the Flags list in privacy.md by name, so the index can flag it.

Examples:
1|TALK|Selfie in the car, winter coat: "taking some time out to plan the year." Slightly dark.
2|SKIP|Walking along a pavement, phone at hip height. Nothing usable.
6|OTHERS|Client group on a course, faces clear. Needs their OK.
19|PRIVATE|Forwarded clip: friends at a birthday.
41|INTERNAL|Screen recording of a team call setup.
90|AD|Garden, hoodie, clean audio: "there are two types of people who click on these adverts."

## Output 2: audience matches
Read every AD, TALK, OTHERS, INTERNAL and HOLD clip with real speech against the themes.

Kept clips (AD, TALK, B-ROLL, POSTED) that hit a theme strongly go in `review/[YEAR]/voc-tags-<your name>.txt`:

`[YEAR]/<file>|T3 T7|"verbatim line from the digest"|One-line use note.`

Strong hits in clips that aren't kept (OTHERS, PRIVATE, INTERNAL, SKIP) go in `review/[YEAR]/voc-rescue-<your name>.txt`:

`[YEAR]/<file>|<LABEL>|T9|"verbatim line"|Use note. Needs X's OK.`

Leave HOLD clips out of both files. Only strong, specific lines count, and having few or none is fine. Copy quotes exactly. A quote with a | in it breaks the file, so cut around it.

## Rules
- Don't edit any other file. Don't copy or move media.
- When done, reply with: lines written, count per label, number of tags and rescues, and the best 3 to 5 clips.
