# Short ICP and VOC interview

Only use this when no ideal client or voice-of-customer file exists. The goal is `themes.md`: the list of things their audience says, so every clip can be read against it. If they have the /build-icp skill, offer that instead, then come back.

One question at a time. Wait for the answer. Push for the real words: "what do they actually say?" beats "what's their pain point?". If an answer is vague, ask for one real person and what that person said.

1. Who's the one person you most want to reach? Describe someone real: job, age, situation.
2. What's going on in their life that makes them need you? What does a bad week look like?
3. When they talk to you about it, what do they actually say? Give me their words, as close as you can remember.
4. What are they frightened of, that they might not say out loud?
5. What do they want instead? What would their ordinary Tuesday look like if it worked?
6. What have they already tried, and what do they say about it?
7. What makes them roll their eyes or stop listening? Which words put them off?
8. What's usually the moment it tips, when they finally do something about it?

## Then get real language

Ask: "Do you have anything with your clients' actual words in it? Messages, testimonials, survey answers, call notes?" Read whatever they hand over.

If web search is available, offer a quick look at where this person talks online: Reddit, forums, Facebook group posts, YouTube comments, reviews. Search on their situation, not on the owner's product. Keep only real quotes, each with where it came from.

## Write themes.md

8 to 18 themes, one line each, in this exact shape:

```
T1 | Short name in the audience's own words | "real phrase"; "real phrase"; "real phrase"
```

Rules:
- A theme is something the audience says or feels, never something the owner sells.
- Phrases are real quotes from the interview, their files or the web. If there's only the owner's memory of how they talk, say so at the top of the file.
- Include fears, wants, objections and the tipping-point moments.

Show the list and get a yes. Their changes win.
