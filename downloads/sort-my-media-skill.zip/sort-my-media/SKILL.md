---
name: sort-my-media
description: Sort a Google Photos library into a searchable media library for business content. Downloads one year at a time with Google Takeout, transcribes every video on this computer, reviews every clip and photo against the owner's ideal client and their audience's own words, keeps private material private, copies the keepers to Google Drive or a local folder, and writes an index Claude can search for ads and content. Use when someone wants to sort, archive or index their Google Photos, find usable footage, says "sort my media", or types /sort-my-media.
---

# Sort my media

You're helping someone who probably isn't technical turn years of Google Photos into a library they can pull ads and content from. You do the technical work. They do a handful of clicks and answer questions a friend could answer.

**Rules for the whole run:**
- One question at a time. Plain words: "folder", not "directory".
- Tell them what's about to happen and roughly how long it takes before each long job.
- Nothing is ever deleted from Google Photos. You never delete anything from their computer either, apart from zips the extract script has unpacked. At the end you hand them a folder to delete themselves.
- Never type a password, and never click the Takeout download links yourself.
- Tick each step in `progress.md` as it finishes.

`<skill>` below means the folder this file is in. All scripts run from the `media-archive` folder. `PY` means `~/.sort-my-media/Scripts/python.exe` on Windows and `~/.sort-my-media/bin/python` on Mac. Run scripts as `PY -I <skill>/scripts/<name>.py <year>`.

## Step 0: Resume or start

Look for `media-archive/progress.md` in the current folder. If it's there, read it, say where things stand in one line, and carry on from the first unticked step. For a new year, add a new year block and start at Step 5.

If it's not there, read `WHAT-TO-EXPECT.md` in `<skill>` and tell them the main points in a few lines, including this one: transcribing happens on their computer, but the frame strips, contact sheets and transcripts are read by Claude, the same as anything else they show it. If there's a year they'd rather keep out of that, skip the year. Ask if they're happy to go on.

Then create `media-archive/` and this `progress.md`:

```
# Sort my media: progress
- [ ] 1 Audience themes
- [ ] 2 Privacy rules
- [ ] 3 Computer set up
- [ ] 4 Destination chosen
## Year: ____
- [ ] 5 Takeout downloaded and unpacked
- [ ] 6 Inventory
- [ ] 7 Transcribed
- [ ] 8 Reviewed
- [ ] 9 Quotes checked
- [ ] 10 Copied and indexed
- [ ] 11 Audience clip page
- [ ] 12 Upload confirmed, tidy-up handed over
## Once
- [ ] 13 CLAUDE.md updated
```

## Step 1: Know the audience first

This comes first because it decides what counts as a good clip. Without it, Claude can only describe footage. With it, Claude can hear the clip where they say what their audience says.

Search the workspace for `ideal-client.md`, `voice-of-customer.md`, an `ABOUT ME` folder, any ICP dossier, or a language bank.

- **Found:** read them and pull out 8 to 18 themes in the format below, using real phrases from those files.
- **Not found:** follow `<skill>/references/icp-voc-mini.md`.

Save `media-archive/themes.md`, one theme per line:

```
T1 | Short name in the audience's words | "real phrase"; "real phrase"
```

Show it and get a yes.

## Step 2: Privacy rules in their words

Ask, one at a time:
1. Who in your life should never appear in anything public? Children, partner, family, anyone else.
2. Is there a hard time in these years, like a loss or an illness, that I should keep well away from? You only need to tell me enough for me to spot it.
3. Are there words or claims your business has to be careful with? Company names, income figures, health claims, anything compliance would flag.
4. Is there an old audience, brand or topic you've moved on from?

Save `media-archive/privacy.md`:

```
# Privacy rules
## Never use
<names and descriptions from questions 1 and 2>
## Flags
<one line per flag: comma-separated words | what the index should say>
client, customer, friends | Other people: get their OK
swear | Swearing
```

The Flags words are matched against review notes, so reviewers name these things when they see them. Add a flag for each person, sensitive word and old topic they gave you.

## Step 3: Set up the computer

Run `python <skill>/scripts/check_setup.py` from `media-archive` (`python3` on Mac). If Python or ffmpeg is missing, it prints the install line. On Mac, if `brew` isn't installed, tell them what Homebrew is and give them the install command from brew.sh to run themselves. After installing ffmpeg on Windows, they need to close and reopen Claude Code.

Then run it again with `--install`. That builds a private `.sort-my-media` folder in their home folder with everything in it, about 2.5 GB with a graphics card and much less without.

Ask what language they speak in their videos. Save `media-archive/config.json`:

```json
{"dest_type": "", "dest": "", "min_free_gb": 40, "model": "distil-large-v3"}
```

`distil-large-v3` is English only. For anything else, or a mix, use `large-v3`. It's slower.

Be straight about speed. With an NVIDIA graphics card, one hour of video took about 3 minutes. On the processor, which includes every Mac, the same hour took about 30. Tell them how that looks against their year once the inventory is done.

## Step 4: Where the keepers go

Ask: **Google Drive or a folder on this computer?** Drive means the library survives a dead laptop and is the better choice if they have the space. Roughly two thirds of a year's data ended up as keepers in the original project, so a 180 GB year needs about 120 GB of Drive.

- **Drive:** they need Google Drive for desktop (google.com/drive/download). Find the folder: on Windows usually `G:\My Drive`, on Mac `~/Library/CloudStorage/GoogleDrive-<email>/My Drive`. Set `dest` to a `Media Library` folder inside it and `dest_type` to `drive`.
- **Folder:** ask where, set `dest` and set `dest_type` to `local`.

The index and transcripts stay in `media-archive/library/`.

## Step 5: Get a year out of Google Photos

Ask which year to start with. Suggest the most recent full year with the most business filming, unless it's huge. A smaller year makes a good first test. Work one year at a time.

Walk them through `<skill>/references/takeout-guide.md`, a few steps at a time. Stress the two things that lose an export: click each part once, and never re-click to retry.

Once they give you the stamp and part count, start in the background:

`PY -I <skill>/scripts/takeout_extract.py <year> <stamp> <parts>`

It unpacks each part as it lands and deletes the zip. If a part logs BAD, the zip stays in Downloads and they should re-download only that part, which uses one of its 5 goes. Move or delete the old copy first, then run the script again.

## Step 6: Inventory

When every part is done: `PY -I <skill>/scripts/build_inventory.py <year>`. Tell them the counts and how long transcribing will take at the speed from Step 3.

## Step 7: Transcribe

In the background: `PY -I <skill>/scripts/transcribe_videos.py <year>`

It writes a transcript and a 3-frame strip per video, and skips what's done, so it can be stopped and restarted. The first run downloads about 1.5 GB. "tuple index out of range" means a clip has no sound, which is fine. With a graphics card, two copies side by side (`--shard 0/2` and `--shard 1/2`) go faster. Run only one heavy job at a time otherwise. Keep the computer plugged in. For a long run, suggest leaving it overnight.

While it runs, build the photo sheets: `PY -I <skill>/scripts/photo_sheets.py <year>`

## Step 8: Review

When transcribing shows DONE, run `PY -I <skill>/scripts/video_review_pack.py <year>` once. Its numbers are used by the batches, so don't rebuild it after review starts.

1. Fill in `<skill>/references/review-brief-videos.md` and `review-brief-photos.md`, saving them as `review/<year>/BRIEF.md` and `BRIEF-photos.md`.
2. If you can start subagents, split the videos across up to six reviewers with separate number ranges and batch numbers, and split the sheets the same way. Each one reads its brief. If not, work through them yourself, a batch at a time.
3. Spot-check the first batch from each reviewer before going on, by opening a sheet and comparing it with the lines.
4. Run `PY -I <skill>/scripts/merge_notes.py <year>`. Fix every PROBLEM line in the batch files and run it again until it's clean.

This uses a lot of their plan's allowance. If a usage limit stops the work, batches already written are safe, so carry on from the first missing batch.

## Step 9: Quote check

`PY -I <skill>/scripts/quote_check.py <year>`

This catches notes that slipped onto the wrong clip, the one mistake that once cost a keeper. For each SLIPPED or NOT FOUND line, compare the note, the transcript and the frame strip, fix the batch file, run `merge_notes.py`, then run this again. Publishing won't start until it passes.

## Step 10: Copy and index

Write `review/<year>/start-here.md`: 5 to 10 bullets on the best clips of the year, each with a file name and a real quote. Then in the background:

`PY -I <skill>/scripts/publish.py <year>`

It's safe to stop and restart. It copies keepers, checks every size and writes `library/INDEX-<year>.md`. It also writes `catalogue/<year>-for-you.md`, the private list of held-back items and ID photos.

Tell them that list exists and that it's for when it suits. Don't read HOLD items aloud.

## Step 11: Audience clip page

Write `media-archive/best-clips.txt` with the top ten as `<year>/<file>`, then run `PY -I <skill>/scripts/build_voc_clips.py`. Then run `PY -I <skill>/scripts/publish.py <year> index` so the main index links it.

Tell them which themes have the most clips, and read out the Gaps list: those are the things their audience says that they've never said on camera, so it's a filming list.

## Step 12: Confirm and tidy up

- **Drive:** ask them to click the Drive for desktop icon and check it says everything's up to date. Then open drive.google.com, find the year's folder and open three files from it.
- **Local folder:** the size check in Step 10 is enough. Suggest a backup.

Only after that, move `raw/<year>` to `raw/_DELETE-ME-<year>` and tell them they can delete it themselves. Everything in it is still in Google Photos. Keep `sheets/` and `frames/` for now, but say they hold thumbnails of private photos too, so they shouldn't be shared.

Ask if they want to go on to another year. Back to Step 5.

## Step 13: Wire it in (first year only)

Add this to their CLAUDE.md (create one in the workspace if there isn't one), with the real path filled in:

```
## Media library
When a piece of work needs a photo or clip, search media-archive/library/INDEX.md and VOC-CLIPS.md first, rather than asking me to send anything. Read the flags before using anything. Never use anything in media-archive/privacy.md's "Never use" list.
```

Finish by showing them one good result: pick a theme and show the best clip for it with its quote.
