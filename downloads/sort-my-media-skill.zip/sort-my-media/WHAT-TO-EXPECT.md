# What to expect

This turns your Google Photos into a library your Claude can search. Ask it for "a clip of me talking about being tired of the day job" and it can go and find one, with the exact words you said.

It reads your stuff against your ideal client first, so it's listening for what your audience says, and it isn't just describing footage. At the end you also get a list of things your audience says that you've never said on camera. That's your filming list.

## What you do
- Answer some questions at the start: who your client is, and who and what must stay private.
- Request a Google Takeout for one year and click the download links. Allow an hour at the computer per year.
- Confirm a sign-in now and then.
- Delete a folder at the end.

Your Claude does the rest.

## What you need
- Claude Code on a Windows PC or Mac, on a plan with plenty of allowance. Reviewing thousands of photos and clips uses a lot. If you hit a limit it picks up where it left off.
- Disk space. A busy year of filming can be 170 GB or more, and you need that plus about 60 GB free. Your Takeout page shows the real size.
- Somewhere for the keepers: Google Drive with room to spare, or a folder on your computer. Expect up to two thirds of the year's size.
- A computer you can leave plugged in overnight.

## How long it takes
Here's what one heavy year took (about 170 GB and 1,600 videos):
- Google preparing the export: minutes to days, it's up to Google.
- Downloading: depends on your internet. At 100 Mbps, 170 GB is around 4 hours.
- Transcribing: with an NVIDIA graphics card, an hour of video takes about 3 minutes. Without one, and that's every Mac, it takes about 30. Leave it overnight.
- Reviewing and copying: most of a day, mostly unattended.

Start with a small year.

## Your privacy
- Your videos are transcribed on your own computer. The audio doesn't go anywhere.
- Claude does look at small thumbnails and read the transcripts, because that's how it sorts them. They go through Claude like anything else you show it, so a passport in your camera roll will be seen by it in order to flag it. If there's a year you'd rather keep out of that, skip the year.
- Family, children, and anything you name as private stay out of the library. If you've been through something hard in these years, tell it briefly and it'll leave that alone and won't bring it up.
- Nothing is deleted from Google Photos. That stays your master copy, so if the sorting gets something wrong you can always fetch the file back.
