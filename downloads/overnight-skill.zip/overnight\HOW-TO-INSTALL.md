# How to install the /overnight skill

This works in **Claude Code** (the VS Code extension, the desktop app's Code tab, or the terminal), not the normal Claude chat app.

1. Unzip this file. You'll get a folder called `overnight` with a file called `SKILL.md` inside.
2. Put that `overnight` folder in your Claude skills folder:
   - **Windows:** `C:\Users\<your name>\.claude\skills\`
   - **Mac:** `~/.claude/skills/` (in Finder, press Cmd+Shift+G and paste that path)
   - If there's no `skills` folder, create one. `.claude` is a hidden folder.
3. Close and reopen Claude Code.
4. Before you go to bed, in any chat that's doing a long job, type `/overnight`.

Or skip the folders: open Claude Code, attach the `SKILL.md` file, and say "install this as a user-level skill called overnight". It'll put it in the right place.
