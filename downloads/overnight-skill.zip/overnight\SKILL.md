---
name: overnight
description: Set a Claude Code session up to keep working unattended, overnight or while you're away, so it picks itself back up after the usage limit resets, the computer wakes from sleep, or a background job stops. Use when the user says /overnight, "I'm going to bed", "keep this running overnight", "carry on while I'm out", "make sure this restarts after the limit", or asks why a session stopped in the night and didn't carry on.
---

# SKILL: overnight

A Claude Code session doesn't restart itself after hitting the usage limit. The limit resets, but nothing tells the session to carry on, so it waits until someone types. What does work is a scheduled wake-up inside the session: an hourly check that keeps firing. While the limit is in force, those checks fail quietly. The first one after the reset gets through and carries on the work.

This skill sets that up, writes a resume point so the wake-up knows exactly what to do, and switches it off once the work is finished, so nothing keeps nudging all night.

## Steps

### 1. Write the resume point

Find or create a progress file in the project folder you're working in (use `progress.md` if one exists; otherwise create `OVERNIGHT.md`). Under a dated heading, write:
- **The task:** what's being done, in one or two lines.
- **Done means:** a concrete check that's true only when the work is finished. For example: "every file in X has a matching file in Y", "the log ends with DONE".
- **How to resume:** the exact commands or steps to pick up where it left off, including how to restart any background jobs. Work must skip anything already done, so re-running is always safe.
- **Where things are right now:** counts, the last item finished.
- **Don't do:** anything that needs the user. Passwords, logins, payments, deleting, publishing and sending stay with them. If the work hits one of these, notify them and wait.

### 2. Schedule the wake-up

Call `CronCreate` with `recurring: true` and an hourly cron at an off-minute (e.g. `17 * * * *`). Use this prompt, with the path filled in:

> Overnight check for <project>. Read <progress file>, the section dated <date>. (1) If "done means" is already true, update the progress file, send the user one PushNotification with what finished, then CronDelete this job and stop. (2) If the work is still running (a background job's log is still growing), reply with one status line and stop. (3) If it has stopped part-way (usage limit, sleep, restart, crash), resume it exactly as the progress file says, skipping anything already done. (4) If it's blocked on something only the user can do, send one PushNotification saying what's needed and stop. Don't ask again until they reply. Stay within this task. Don't start anything new.

Hourly is the right pace: the usage limit resets on the hour scale, and a check costs very little. Recurring jobs expire after 7 days on their own.

If PushNotification isn't available (phone notifications need Remote Control set up), skip the notifications. Everything is still written in the progress file and the chat.

### 3. Check the computer will stay awake

Check, and tell the user about anything that's wrong:
- **Plugged in?** On battery, a laptop sleeps when the charge runs low, even with sleep set to never, and the work pauses.
- **Sleep while plugged in set to never?** On Windows: `powercfg /query SCHEME_CURRENT SUB_SLEEP STANDBYIDLE`, where AC index 0 means never. On a Mac: System Settings, then Battery, then the options for preventing sleep on power adapter.

### 4. Tell the user, briefly

- what's set to carry on, and what "done" looks like
- that the check runs hourly and switches itself off when the work is done
- keep the editor or terminal running Claude Code open, the computer on and plugged in, and don't close this chat. The wake-up lives in this session.

## Limits to be straight about

- It only works while this session is open. Close it and the wake-up goes with it. Resuming the chat restores scheduled jobs that haven't expired, but not background jobs. The progress file is how those get restarted.
- Background jobs keep running on the computer during a usage limit. It's only Claude's own turns that stop.
- Each chat needs its own `/overnight`.
- For work that doesn't need files on this computer, a cloud schedule (`/schedule`) runs even with the computer off.
